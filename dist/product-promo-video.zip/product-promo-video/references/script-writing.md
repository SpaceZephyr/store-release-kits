# 脚本、文案和配音

## 结构

宣传片的观众通常只给你前 3 秒。所以：

1. **第一场就亮 logo 和 slogan**，别铺垫。
2. **第二场一句话说清这是什么**（slogan 场）。说「是什么」，不说「多厉害」。
3. 中间 2–4 场讲**使用场景**和**核心功能**，每场只讲一件事，配真实截图。
4. 倒数第二场放**证据**：数据（stats）、用户声音（tags）、生态（gallery）。
5. 最后一场 logo + slogan + 行动（网址、下载、搜索词）。

时长参考：信息流投放 15–30 秒（4–5 场），官网 / 发布会 40–60 秒（6–8 场）。

## 屏幕文案

- 标题一行最多 8 个字，两行封顶。用 `\n` 自己断句，竖版尤其要断。
- 想让某几个字跳出来就用 `**` 包起来：`打开就有\n**想看的**`。一句只强调一处。
- kicker 是标题上面的小标签，写栏目名或出处：「首页推荐」「2026 年第二季度」。
- 副标题写具体的东西（「番剧、知识、游戏、生活」），不写「高效便捷」「极致体验」这类空话。
- 屏幕文案和旁白**不要一模一样**。屏幕上放关键词，旁白说完整的话。

## 旁白（say）

- 每场 1–2 句，15–30 个字。旁白的长度决定这一场的时长。
- 写成说出来的话：短句，有停顿，少用书面连接词（「此外」「与此同时」「值得一提的是」）。
- 数字写成读音：`3.71 亿` → 「三点七一亿」，`113 分钟` → 「一百一十三分钟」。TTS 读阿拉伯数字经常读错。
- 英文和缩写看 TTS 能不能读：`B站` 可以，`UP主` 可以，`awsl` 这种别放进旁白。
- 结尾一句短一点（「哔哩哔哩，干杯！」），给 logo 留出画面时间。

## 配音引擎

| 引擎 | 效果 | 什么时候用 |
| --- | --- | --- |
| edge-tts | 最自然，有多种中文音色 | 默认首选，需要联网 |
| macOS say（婷婷） | 能听清但机械感重 | edge-tts 不可用时自动退回 |
| kokoro | 本地模型，中文一般 | 离线且没有 say 时 |
| 真人录音 `voiceFile` | 最好 | 正式投放 |

edge-tts 推荐音色：男声 `zh-CN-YunxiNeural`（年轻）、`zh-CN-YunjianNeural`（沉稳）、`zh-CN-YunyangNeural`（播音）；
女声 `zh-CN-XiaoxiaoNeural`（温暖）、`zh-CN-XiaoyiNeural`（活泼）。语速快节奏风格 +10%~+15%，发布会风格 -2%~-5%。

## 场景素材

- `feature` 截图优先用桌面首屏（`shot-desktop.png`）和手机版（`shot-mobile.png`）。
  横版里手机截图配 `"frame": "phone"`，桌面截图配 `"frame": "browser"`。
- `focus: [x, y, 放大倍数]` 让截图在这一场后半段慢慢推近到 (x, y) 位置，x、y 是 0–1 的相对坐标，适合突出某个按钮或区域。
- `cards` 的图标用 Lucide 线性图标名（https://lucide.dev/icons ，本地在 `scripts/node_modules/lucide-static/icons/`），
  也可以用 `image` 放截图裁出来的局部；两个都不写就显示 01、02 序号。**不要用 emoji。**
  常用：视频 `clapperboard` `tv-minimal` `play`、学习 `graduation-cap` `book-open`、游戏 `gamepad-2`、音乐 `music`、
  美食 `utensils`、科技 `cpu`、AI `sparkles` `bot`、办公 `briefcase`、出行 `train-front` `car`、家 `house`、
  社交 `messages-square` `users`、购物 `shopping-bag`、安全 `shield-check`、速度 `zap`、数据 `chart-line`。
- `tags` 写 15–25 条，长短混搭；弹幕模式下条目越多越像真弹幕。
